# Voice Chat Application using UDP with Text Chat

An educational computer-networks laboratory prototype that keeps two transport
lanes independent within one desktop session:

- Voice uses **UDP** because a late PCM frame has little value. The application
  can drop stale frames and keep playing newer ones.
- Text uses **TCP** because a typed message remains valuable after delay. TCP
  gives ordered, reliable bytes; this app adds length-prefixed framing so one
  `recv()` never has to equal one chat message.

> Educational laboratory prototype. It does not claim encryption,
> authentication, NAT traversal, codec compression, production QoS, or
> production-grade VoIP security.

## What is included

```text
voice_chat_project/
├── app.py                 # desktop entry point and headless socket self-test
├── config.py              # audio and LAN/loopback settings
├── audio_io.py            # real sounddevice/PortAudio PCM and explicit test-audio mode
├── protocol.py            # UDP binary header and TCP length-prefix format
├── voice_udp.py           # UDP endpoint and freshness-first playout buffer
├── text_tcp.py            # TCP server/client and framed stream receive loop
├── workers.py             # independent workers, queues, session lifecycle
├── network_simulator.py   # UDP-only loss, delay, jitter, reordering injector
├── metrics.py             # measured counters, timing records, CSV export
├── logger.py              # UI queue and timestamped event logs
├── ui.py                  # polished Tkinter demonstration dashboard
├── requirements.txt
├── TEST_PLAN.md
└── tests/
```

## Architecture

```text
VOICE LANE (UDP)                         TEXT LANE (TCP)
Microphone / test PCM                    Text input
  → capture worker                         → TCP send worker
  → packet header + PCM                    → [length][UTF-8 JSON]
  → optional UDP simulator                 → TCP receive worker
  → UDP sendto / recvfrom                  → thread-safe chat queue
  → bounded playout queue                  → chat window
  → speaker
```

The workers never perform blocking sockets in the Tkinter UI thread. TCP
receiving, UDP receiving, audio capture, and audio playback have independent
threads. Thread-safe queues protect the handoffs to playback and UI rendering.

## UDP packet format

Each voice datagram contains a binary, inspectable header followed by raw int16
PCM audio:

```text
magic (4 bytes) | version (1) | sequence (4) | timestamp ns (8) | payload length (2) | PCM payload
```

Sequence gaps identify potential loss. Duplicate and out-of-order packets are
also recorded. No TCP-like retransmission is attempted for voice. The receiver
uses a bounded queue and removes stale queue-head frames if it gets full, which
keeps latency from growing without limit.

## Requirements

- Python 3.10 or later
- A desktop display for the GUI
- For real microphone/speaker mode: `sounddevice` and a working PortAudio audio
  device. The program includes **Simulation / Audio Test Mode** for lab demos
  without audio hardware. That mode sends silent PCM through the *real UDP
  sockets* and remains visibly labelled as simulation.

## Install

### macOS

```bash
cd /path/to/voice_chat_project
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
python3 app.py
```

If macOS blocks microphone access, allow your Terminal or Python application in
**System Settings → Privacy & Security → Microphone**. If `sounddevice` cannot
find PortAudio, install an appropriate PortAudio package for your Python setup,
then reinstall `sounddevice`.

### Windows PowerShell

```powershell
cd C:\path\to\voice_chat_project
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
py app.py
```

## Start a host and client

Run `python app.py` in each terminal. In the first application:

1. Leave **Local IP** as `0.0.0.0` for LAN listening, or use `127.0.0.1` for a
   local-only demonstration.
2. Set **TCP port** to `51000`, **Local UDP** to `51001`, and **Peer UDP** to
   the other instance’s local UDP port.
3. Click **HOST**.

In the peer application:

1. Set **Peer IP** to the host’s LAN IP, or `127.0.0.1` for loopback.
2. Keep **TCP port** at the host value (`51000`).
3. Set **Local UDP** to `51002`, **Peer UDP** to `51001`.
4. Click **CONNECT**.

For a local two-instance demo, the exact values are:

| Instance | Local IP | Peer IP | TCP port | Local UDP | Peer UDP |
|---|---:|---:|---:|---:|---:|
| Host | `127.0.0.1` | `127.0.0.1` | `51000` | `51001` | `51002` |
| Client | `127.0.0.1` | `127.0.0.1` | `51000` | `51002` | `51001` |

Click **START REAL VOICE** after TCP connects. If audio hardware is not ready,
click **START TEST AUDIO** in both windows. Test mode proves packetisation,
UDP, buffering, metrics, and network simulation, but it deliberately does not
claim a physical microphone/speaker result.

To find a LAN IP: on macOS use `ipconfig getifaddr en0` (Wi-Fi is commonly
`en0`); on Windows run `ipconfig` and use the IPv4 address for the active
adapter. Both devices must be on the same LAN.

## Demonstrate the project to a professor

1. Start the host and client with the loopback table above.
2. Send text both ways. Point to the **TCP Message Inspector** and the ordered
   message IDs.
3. Start real voice, or labelled test audio if hardware cannot be used. Point
   to the **UDP Voice Packet Inspector**, sequence numbers, and the bounded
   playout queue metric.
4. Select **5% LOSS** in **UDP network simulator**. The inspector records
   `SIMULATED LOSS`; new voice packets continue. Send TCP text at the same time
   and show that it still arrives in order.
5. Switch to **HIGH JITTER** or **HIGH DELAY**, then compare measured UDP
   arrival interval / estimated playout with unchanged TCP framing.
6. Click **DISCONNECT** and explain that workers stop, sockets close, audio
   streams release, and queues clear.

The **DEMO MODE** pane supplies this same five-step guided sequence. The
**ABOUT / VIVA** pane gives concise explanations matching the implementation.

## Test UDP loss, delay, jitter, and reordering

The simulator sits directly before the program’s actual `socket.sendto()` call.
It never handles TCP.

1. Start two peers and test audio in both.
2. Choose a preset, or set packet loss, delay, jitter, and reordering manually.
3. Click **APPLY UDP CONDITIONS**.
4. Observe event log records such as `Voice packet #... dropped by UDP
   simulator`, inspector status, sequence gaps, arrival intervals, and queue
   depth.
5. Use **EXPORT METRICS** to write the actual inspector observations to CSV.

Use one network variable at a time for a meaningful experiment. The simulator
reports intentionally injected drops as **simulated**, not as a measured
physical-network impairment. Capture-to-playout uses endpoint timestamps and
is an **estimated** value, especially across machines with unsynchronised clocks.

## Test TCP reliability and order

Send a burst of numbered messages: `msg 1`, `msg 2`, ... `msg 10`. The TCP
Message Inspector should show each frame with `RECEIVED` status in order. The
receiver buffers partial reads and decodes all complete frames from a coalesced
read, so it does not assume `recv()` matches a message boundary.

## Automated tests and headless verification

```bash
python -m pytest
python app.py --self-test
```

The self-test starts genuine localhost TCP server/client sockets, exchanges two
framed messages, sends silent PCM over genuine localhost UDP sockets, applies
20% simulated UDP loss, observes real counters, and shuts both sessions down.
It requires no GUI or audio hardware.

## Measurement honesty

The dashboard starts timing values at `N/A`; it does not invent baseline
numbers. Its charts use only collected event histories. Labels distinguish:

- **Measured**: local packet and message events observed by this process.
- **Simulated**: loss/delay/jitter/reordering deliberately applied at the UDP
  sender boundary.
- **Estimated**: capture-to-playout and cross-machine timing derived from local
  endpoint clocks, which are not a scientifically precise one-way network delay
  without clock synchronisation.

## Troubleshooting

| Symptom | Check |
|---|---|
| `TCP: DISCONNECTED` after Connect | Confirm host started first, Peer IP is correct, TCP port matches, and no firewall blocks inbound TCP. |
| UDP counts stay at zero | Confirm both local/peer UDP ports are reciprocal and distinct on one computer. Check firewall rules for inbound UDP. |
| Port already in use | Pick a different TCP port and two different UDP ports in both instances. |
| Voice start fails | Check microphone permission, speaker, `sounddevice`, and PortAudio. Use **START TEST AUDIO** to prove the network architecture while diagnosing audio. |
| LAN client cannot connect | Use the host’s active LAN IP, ensure both devices share a network, disable client isolation, and permit TCP/UDP ports in the OS firewall. |
| UI will not start in CI/headless shell | Run `python app.py --self-test`. The GUI needs a desktop display. |

## Known limitations and future scope

The prototype supports one TCP peer, raw PCM, IPv4, and manually configured
addresses. It has no encryption/authentication, NAT traversal, codec,
RTP/RTCP, adaptive jitter buffer, packet-loss concealment, automatic reconnect,
or guaranteed QoS. These are deliberate limits of a transparent TRL 4
laboratory prototype. Future work: authentication, encryption, RTP/codec
support, NAT traversal, adaptive playout control, and production monitoring.

## Remote access and deployment constraints

This deliverable is a **desktop Tkinter application** that opens actual TCP and UDP sockets. It is not a browser app, HTTP API, or static site, so GitHub Pages and ordinary static hosting cannot run it. No public demo URL has been deployed.

For a same-LAN demonstration, run both application instances on computers on the same network and allow TCP port `51000` plus the chosen UDP voice ports through each computer's firewall. For cross-internet use, each endpoint must have a reachable UDP path and the TCP host must be reachable; NAT, router port-forwarding, public IP changes, and firewalls may prevent direct peer-to-peer traffic. Do not expose the prototype to the public internet for sensitive conversations: the application does not provide encryption or authentication.

A reliable browser-based online demo would require a separate WebRTC architecture (browser audio capture, WebSocket signaling, STUN/TURN as needed). That changes the transport layer rather than simply hosting this desktop code. This repository intentionally preserves the original TCP/UDP implementation rather than claiming that it is already a web deployment.

## Test results recorded for this source snapshot

Validated in the available Linux environment on 2026-10-19:

- `python -m pytest` — **13 passed**.
- `python app.py --self-test` — passed: bidirectional framed text over real localhost TCP sockets and silent test PCM over real localhost UDP sockets; 10 UDP packets sent, 8 received, and 2 intentionally dropped by the configured simulator in this run.

Physical microphone/speaker operation and multi-computer LAN/WAN connectivity were not verified in this environment; perform those checks on the presentation devices.
